<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "frs";
$connect = mysqli_connect($host, $username, $password, $database);
?>